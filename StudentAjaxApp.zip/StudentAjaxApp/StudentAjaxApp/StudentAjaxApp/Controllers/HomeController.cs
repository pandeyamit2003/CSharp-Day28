using Microsoft.AspNetCore.Mvc;
using StudentAjaxApp.Models;

namespace StudentAjaxApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetStudent(int id)
        {
            List<Student> students = new List<Student>()
            {
                new Student
                {
                    StudentId = 1,
                    Name = "Rahul",
                    Course = "BCA",
                    Age = 20
                },

                new Student
                {
                    StudentId = 2,
                    Name = "Aman",
                    Course = "MCA",
                    Age = 22
                },

                new Student
                {
                    StudentId = 3,
                    Name = "Priya",
                    Course = "B.Tech",
                    Age = 21
                }
            };

            var student = students.FirstOrDefault(s => s.StudentId == id);

            if (student == null)
            {
                return Json(new
                {
                    success = false,
                    message = "Student Not Found"
                });
            }

            return Json(new
            {
                success = true,
                data = student
            });
        }
    }
}